#include "..\core.h"

void Init_system();

int main()
{
	Init_system();

	// initialize demo
	Demo_init();

	// main loop
	while(1)
	{
		// cache pad reads
		Read_pad();
		// reset gs handlers and packet
		GsBeginDraw();
		// logic
		Demo();
		// draw and swap
		GsEndDraw();
	}

	return 0;
}

void Init_system()
{
	// reset callback environment
	ResetCallback();
	// init cd and spu
	Cd_init();
	Snd_init();
	// initialize GPU and GTE
	SetGraphDebug(0);
	InitGeom();
	SetGeomOffset(RES_W / 2, RES_H / 2);
	// init controllers
	InitControllers();
	// reset graphics and set gpu into NTSC mode
	SetVideoMode(0);
	ResetGraph(0);
	// clear all vram
	Vram_clear();
	// enable display
	SetDispMask(1);

	// set frame buffer and clear mode
	GsSetDisplay(0, 0, RES_W, RES_H, RESMODE_SIDEWAYS);
	GsSetClearMode(GCM_NONE);
	// set packet buffers
	GsInitPacket();
}
