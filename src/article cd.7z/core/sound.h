#ifndef __SOUND_H
#define __SOUND_H

void Snd_init();

#endif
