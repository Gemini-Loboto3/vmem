#ifndef __VRAM_H
#define __VRAM_H

void Vram_clear();
void Upload_tim(u32 *data);
void Upload_tpk(u32 *data);

#endif
