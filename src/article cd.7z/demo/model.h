#ifndef __MODEL_H
#define __MODEL_H

void Swirl_init(ENTITY *pEnt);

#endif
