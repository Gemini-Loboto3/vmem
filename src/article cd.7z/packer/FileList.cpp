#include "FileList.h"
#include <string.h>

CFileList::CFileList(FILE *fp)
{
	// get size
	int size;
	fseek(fp, 0, SEEK_END);
	size = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	// cache data
	buffer = new char[size + 1];
	fread(buffer, size, 1, fp);
	// add string terminator
	buffer[size] = '\0';

	seek = NULL;
}

CFileList::~CFileList()
{
	if (buffer) delete[] buffer;
}

char* CFileList::GetNextToken()
{
	// get token from previous process
	if (seek) seek = strtok(NULL, "\r\n");
	// tokenize for the first time
	else seek = strtok(buffer, "\r\n");

	return seek;
}
