#pragma once
#include "stdafx.h"

class CFileList
{
public:
	CFileList(FILE *fp);
	~CFileList();

	char *GetNextToken();

	char *buffer, *seek;
};

