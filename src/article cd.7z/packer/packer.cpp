// packer.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "..\core\common.h"
#include "FileList.h"
// a few undef to make common.h usable with std
#undef false
#undef true
#undef offsetof
// C++ std
#include <vector>
#include <string>

// main structures of package
typedef struct tagPackHeader
{
	u32 count,
		sectors;
} PACK_HEADER;

typedef struct tagPackFile
{
	u32 lba,
		size;
} PACK_FILE;

void print_usage()
{
	printf("Usage: packer -<mode> <file list> <output package>\n\n"
		"Modes:\n"
		" p: create package for main data container.\n"
		" d: create package for simple data container (like textures)\n\n"
		"Example: packer -p list.txt bigfile.pak\n");
}

void build_path(char *str, char *dst)
{
	int size = 0;
	char *tmp;
	// copy and count size
	while (*str)
	{
		*dst++ = *str++;
		size++;
	}

	// search path mark
	tmp = &dst[size - 1];
	while (*tmp != '\\') tmp--;
	// replace '\\' with termination
	*tmp = '\0';
}

void process(CFileList &list, FILE *out, int mode, char *path)
{
	char *token, fname[_MAX_PATH];
	int size;
	u8 *buffer;

	std::vector<std::string> names;

	size_t si = 0;
	// build name list
	while ((token = list.GetNextToken()))
	{
		// ignore invalid tokens
		if (token[0] == '\n' || token[0] == '\0') continue;
		std::string s = token;
		names.push_back(s);
		si++;
	}
	// reserve enough file entries
	PACK_FILE *f = new PACK_FILE[si];

	// skip header
	if (mode != 0)	// small file, preallocates room for pointers
		fseek(out, 4 * si, SEEK_SET);
	else			// big file, preallocates full header and entries
		fseek(out, GetAlign(sizeof(PACK_FILE) * si + sizeof(PACK_HEADER), 2048), SEEK_SET);

	// read all tokens from list
	for (size_t i = 0; i < si; i++)
	{
		sprintf(fname, "%s\\%s", path, names[i].c_str());
		FILE *in = fopen(fname, "rb+");

		if (!in)
		{
			printf("Can't find file %s, skipping...", fname);
			continue;
		}

		// gather file size
		fseek(in, 0, SEEK_END);
		size = ftell(in);
		fseek(in, 0, SEEK_SET);

		if (size == 0) printf("File %s is empty, skipping...", fname);
		else
		{
			int ssize;
			// write to main packer
			if (mode == 0)
			{
				// pad to a sector
				ssize = GetAlign(size, 2048);
				f[i].lba = ftell(out) / 2048;
				// set size
				f[i].size = size;
			}
			// write to data packer
			else
			{
				// pad to a word
				ssize = GetAlign(size, 4);
				f[i].lba = ftell(out);
			}

			// cache data
			buffer = new u8[ssize];
			fread(buffer, size, 1, in);
			memset(&buffer[size], 0, ssize - size);	// clear lead out area
			// write with padded size
			fwrite(buffer, ssize, 1, out);
			// free buffer
			delete[] buffer;
		}
		fclose(in);
	}

	// go back to header and fill it
	fseek(out, 0, SEEK_SET);
	// big file
	if (mode == 0)
	{
		PACK_HEADER header;
		// populate header
		header.count = (u32)si;
		header.sectors = GetAlign(sizeof(PACK_FILE) * si + sizeof(PACK_HEADER), 2048) / 2048;
		// write header
		fwrite(&header, sizeof(header), 1, out);
		// write allocation tables
		fwrite(f, sizeof(PACK_FILE), si, out);
	}
	// small file
	else
	{
		// write pointer data
		for (size_t i = 0; i < si; i++)
			fwrite(&f[i].lba, 4, 1, out);
	}
	// clear allocators
	delete[] f;
}

int main(int argc, char *argv[])
{
	int mode;
	char path[_MAX_PATH];

	printf("Generic PlayStation packer %d.\n\n",argc);

	if (argc < 4)
	{
		print_usage();
		return 1;
	}

	if (argv[1][0] == '-')
	{
		switch (argv[1][1])
		{
		case 'p':	// package
			mode = 0;
			break;
		case 'd':	// data storage
			mode = 1;
			break;
		case 'h':
			print_usage();
			return 1;
		default:
			printf("Unrecognized mode %s.\n", argv[1]);
			return 1;
		}
	}
	else
	{
		print_usage();
		return 1;
	}

	FILE *inlist = fopen(argv[2], "rb+");
	if (!inlist)
	{
		printf("Cannot open list %s.\n", argv[2]);
		return 1;
	}

	FILE *outpak = fopen(argv[3], "wb");
	if (!outpak)
	{
		printf("Cannot create package %s.\n", argv[3]);
		fclose(inlist);
		return 1;
	}

	CFileList list(inlist);

	build_path(argv[2], path);
	process(list, outpak, mode, path);

	fclose(inlist);
	fclose(outpak);

    return 0;
}
